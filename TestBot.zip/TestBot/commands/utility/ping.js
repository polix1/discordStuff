const { SlashCommandBuilder } = require("discord.js");


module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('pongs you'),
    async excute(interactions) {
        await interactions.reply('i ponged you');
    },

};
